#ifndef VISUALIZER_H
#define VISUALIZER_H

#include <GL/glut.h>
#include <vector>
#include <string>
#include <opencv2/core.hpp>

// Estructura para representar un triángulo 3D
struct Triangle {
    float x1, y1, z1;
    float x2, y2, z2;
    float x3, y3, z3;
};

class Visualizer {
public:
    Visualizer(int argc, char** argv);
    void loadTrianglesFromFile(const std::string& filename);
    void run();
    void display() const;
    void setPose(const cv::Mat& rotationVector, const cv::Mat& translationVector);

private:
    static Visualizer* instance;
    static void displayCallback();
    static void reshapeCallback(int width, int height);
    
    void reshape(int width, int height);
    void initGL();

    std::vector<Triangle> triangles;
    cv::Mat rotationVector;
    cv::Mat translationVector;
};

#endif // VISUALIZER_H
