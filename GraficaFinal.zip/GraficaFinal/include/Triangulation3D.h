#ifndef TRIANGULATION3D_H
#define TRIANGULATION3D_H

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/Surface_mesh.h>
#include <CGAL/convex_hull_3.h>
#include <CGAL/Triangulation_3.h>
#include <vector>
#include <string>

typedef CGAL::Exact_predicates_inexact_constructions_kernel K;
typedef K::Point_3 Point_3;
typedef CGAL::Triangulation_3<K> Triangulation_3;
typedef Triangulation_3::Cell_handle Cell_handle;

class Triangulation3D {
public:
    Triangulation3D();
    void loadPointsFromFile(const std::string& filename);
    void performTriangulation();
    void saveTriangulationToFile(const std::string& filename) const;

private:
    std::vector<Point_3> points;
    Triangulation_3 triangulation;
};

#endif // TRIANGULATION3D_H
