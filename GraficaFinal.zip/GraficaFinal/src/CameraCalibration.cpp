#include "CameraCalibration.h"
#include <iostream>

CameraCalibration::CameraCalibration(int boardWidth, int boardHeight, float squareSize)
    : boardWidth(boardWidth), boardHeight(boardHeight), squareSize(squareSize), boardSize(boardWidth, boardHeight) {
}

void CameraCalibration::addImage(const cv::Mat& image) {
    cv::Mat gray;
    cv::cvtColor(image, gray, cv::COLOR_BGR2GRAY);

    std::vector<cv::Point2f> corners;
    bool found = cv::findChessboardCorners(gray, boardSize, corners,
        cv::CALIB_CB_ADAPTIVE_THRESH | cv::CALIB_CB_NORMALIZE_IMAGE);

    if (found) {
        cv::cornerSubPix(gray, corners, cv::Size(11, 11), cv::Size(-1, -1),
            cv::TermCriteria(cv::TermCriteria::EPS + cv::TermCriteria::COUNT, 30, 0.1));

        imgPoints.push_back(corners);
        objPoints.push_back(create3DChessboardCorners());

        imageSize = gray.size(); // Añadido

    }
}

void CameraCalibration::calibrate() {
    if (imgPoints.empty()) {
        std::cerr << "No hay puntos de imagen para calibrar" << std::endl;
        return;
    }

    double rms = cv::calibrateCamera(objPoints, imgPoints, imageSize, cameraMatrix, distCoeffs, rvecs, tvecs);

}

void CameraCalibration::saveCalibration(const std::string& filename) {
    cv::FileStorage fs(filename, cv::FileStorage::WRITE);
    fs << "cameraMatrix" << cameraMatrix;
    fs << "distCoeffs" << distCoeffs;
    fs.release();
}

std::vector<cv::Point3f> CameraCalibration::create3DChessboardCorners() {
    std::vector<cv::Point3f> corners;
    for (int i = 0; i < boardHeight; ++i) {
        for (int j = 0; j < boardWidth; ++j) {
            corners.push_back(cv::Point3f(j * squareSize, i * squareSize, 0));
        }
    }
    return corners;
}
