#ifndef CAMERA_CALIBRATION_H
#define CAMERA_CALIBRATION_H

#include <opencv2/opencv.hpp>
#include <vector>

class CameraCalibration {
public:
    CameraCalibration(int boardWidth, int boardHeight, float squareSize);
    void addImage(const cv::Mat& image);
    void calibrate();
    void saveCalibration(const std::string& filename);

private:
    int boardWidth;
    int boardHeight;
    float squareSize;
    cv::Size boardSize;
    std::vector<std::vector<cv::Point2f>> imgPoints;
    std::vector<std::vector<cv::Point3f>> objPoints;
    cv::Mat cameraMatrix;
    cv::Mat distCoeffs;
    std::vector<cv::Mat> rvecs;
    std::vector<cv::Mat> tvecs;
    std::vector<cv::Point3f> create3DChessboardCorners();
    cv::Size imageSize; // Añadido
};

#endif // CAMERA_CALIBRATION_H
