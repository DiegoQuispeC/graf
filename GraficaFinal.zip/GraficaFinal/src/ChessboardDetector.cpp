#include "ChessboardDetector.h"
#include <opencv2/calib3d.hpp>
#include <fstream>  // Incluir <fstream> para el manejo de archivos
#include <iostream> // Incluir <iostream> para el manejo de la salida de errores

ChessboardDetector::ChessboardDetector(int cornersX, int cornersY, float squareSize)
    : cornersX(cornersX), cornersY(cornersY), squareSize(squareSize), patternSize(cornersX, cornersY) {

    // Inicializar objectPoints con las coordenadas 3D de las esquinas del tablero
    float offsetX = (cornersX - 1) * squareSize / 2.0f;
    float offsetY = (cornersY - 1) * squareSize / 2.0f;
    
    objectPoints.push_back(cv::Point3f(0 - offsetX, 0 - offsetY, 0));                     // Esquina superior izquierda
    objectPoints.push_back(cv::Point3f((cornersX - 1) * squareSize - offsetX, 0 - offsetY, 0));             // Esquina superior derecha
    objectPoints.push_back(cv::Point3f(0 - offsetX, (cornersY - 1) * squareSize - offsetY, 0));             // Esquina inferior izquierda
    objectPoints.push_back(cv::Point3f((cornersX - 1) * squareSize - offsetX, (cornersY - 1) * squareSize - offsetY, 0)); // Esquina inferior derecha

    // Configuración de la cámara (suponiendo una cámara pre-calibrada)
    cameraMatrix = (cv::Mat_<double>(3, 3) << 1000, 0, 640, 0, 1000, 360, 0, 0, 1);
    distCoeffs = cv::Mat::zeros(5, 1, CV_64F);
}

bool ChessboardDetector::detect(const cv::Mat& frame, std::vector<cv::Point2f>& cornerPoints) {
    return cv::findChessboardCorners(frame, patternSize, cornerPoints);
}

void ChessboardDetector::drawCorners(cv::Mat& frame, const std::vector<cv::Point2f>& cornerPoints) {
    // Dibujar solo las esquinas
    if (!cornerPoints.empty()) {
        std::vector<cv::Point2f> corners;
        corners.push_back(cornerPoints[0]);                                  // Esquina superior izquierda
        corners.push_back(cornerPoints[cornersX - 1]);                       // Esquina superior derecha
        corners.push_back(cornerPoints[(cornersY - 1) * cornersX]);        // Esquina inferior izquierda
        corners.push_back(cornerPoints[cornersY * cornersX - 1]);          // Esquina inferior derecha
        for (const auto& point : corners) {
            cv::circle(frame, point, 5, cv::Scalar(0, 255, 0), -1); // Dibujar las esquinas en verde
        }
    }
}

bool ChessboardDetector::estimatePose(const std::vector<cv::Point2f>& cornerPoints, cv::Mat& rotationVector, cv::Mat& translationVector) {
    if (cornerPoints.size() < 4) {
        return false;
    }
    
    std::vector<cv::Point2f> corners;
    corners.push_back(cornerPoints[0]);                                  // Esquina superior izquierda
    corners.push_back(cornerPoints[cornersX - 1]);                       // Esquina superior derecha
    corners.push_back(cornerPoints[(cornersY - 1) * cornersX]);        // Esquina inferior izquierda
    corners.push_back(cornerPoints[cornersY * cornersX - 1]);          // Esquina inferior derecha

    return cv::solvePnP(objectPoints, corners, cameraMatrix, distCoeffs, rotationVector, translationVector);
}

void ChessboardDetector::drawAxes(cv::Mat& frame, const cv::Mat& rotationVector, const cv::Mat& translationVector) {
    std::vector<cv::Point3f> axisPoints = { 
        cv::Point3f(0, 0, 0), 
        cv::Point3f(squareSize, 0, 0), 
        cv::Point3f(0, squareSize, 0), 
        cv::Point3f(0, 0, -squareSize) 
    };
    std::vector<cv::Point2f> imagePoints;
    cv::projectPoints(axisPoints, rotationVector, translationVector, cameraMatrix, distCoeffs, imagePoints);

    cv::line(frame, imagePoints[0], imagePoints[1], cv::Scalar(0, 0, 255), 2); // Eje X en rojo
    cv::line(frame, imagePoints[0], imagePoints[2], cv::Scalar(0, 255, 0), 2); // Eje Y en verde
    cv::line(frame, imagePoints[0], imagePoints[3], cv::Scalar(255, 0, 0), 2); // Eje Z en azul
}

void ChessboardDetector::loadTriangulationResults(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "No se puede abrir el archivo " << filename << std::endl;
        return;
    }

    std::vector<cv::Point3f> loadedPoints;
    float x, y, z;
    while (file >> x >> y >> z) {
        loadedPoints.push_back(cv::Point3f(x, y, z));
    }
    file.close();

    // Calcular el centro de masa de los puntos
    cv::Point3f centerOfMass(0, 0, 0);
    for (const auto& point : loadedPoints) {
        centerOfMass += point;
    }
    centerOfMass *= (1.0f / loadedPoints.size());

    // Trasladar los puntos al origen
    for (auto& point : loadedPoints) {
        point -= centerOfMass;
    }

    // Escalar los puntos para ajustarlos al tamaño del tablero
    float maxDim = 0;
    for (const auto& point : loadedPoints) {
        maxDim = std::max(maxDim, std::max(std::abs(point.x), std::max(std::abs(point.y), std::abs(point.z))));
    }
    float scale = (squareSize * (cornersX - 1)) / maxDim / 2.0f;
    for (auto& point : loadedPoints) {
        point *= scale;
    }

    // Guardar los puntos escalados y centrados
    triangulationPoints = loadedPoints;
}

void ChessboardDetector::drawTriangles(cv::Mat& frame, const cv::Mat& rotationVector, const cv::Mat& translationVector) {
    if (triangulationPoints.empty()) {
        std::cerr << "No hay puntos de triangulación para dibujar" << std::endl;
        return;
    }

    std::vector<cv::Point2f> imagePoints;
    cv::projectPoints(triangulationPoints, rotationVector, translationVector, cameraMatrix, distCoeffs, imagePoints);

    for (size_t i = 0; i < imagePoints.size(); i += 3) {
        cv::line(frame, imagePoints[i], imagePoints[i+1], cv::Scalar(255, 0, 0), 1);
        cv::line(frame, imagePoints[i+1], imagePoints[i+2], cv::Scalar(255, 0, 0), 1);
        cv::line(frame, imagePoints[i+2], imagePoints[i], cv::Scalar(255, 0, 0), 1);
    }
}
