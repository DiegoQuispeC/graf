#include "Visualizer.h"
#include <fstream>
#include <iostream>
#include <opencv2/calib3d.hpp>

// Inicializa la instancia estática
Visualizer* Visualizer::instance = nullptr;

// Función de callback estática que llama al método de instancia
void Visualizer::displayCallback() {
    if (instance) {
        instance->display();
    }
}

// Función de ajuste estática para cambiar el tamaño de la ventana
void Visualizer::reshapeCallback(int width, int height) {
    if (instance) {
        instance->reshape(width, height);
    }
}

// Constructor
Visualizer::Visualizer(int argc, char** argv) {
    // Establece la instancia actual
    instance = this;

    // Inicializa GLUT
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(600, 600); // Establece el tamaño de la ventana
    glutCreateWindow("3D Triangulation Visualization");

    glutDisplayFunc(displayCallback); // Establece el callback de visualización
    glutReshapeFunc(reshapeCallback);  // Establece el callback para el redimensionamiento

    initGL();
}

// Carga los triángulos desde el archivo
void Visualizer::loadTrianglesFromFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }

    Triangle t;
    while (file >> t.x1 >> t.y1 >> t.z1
                >> t.x2 >> t.y2 >> t.z2
                >> t.x3 >> t.y3 >> t.z3) {
        triangles.push_back(t);
    }

    file.close();
}

// Inicializa OpenGL
void Visualizer::initGL() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

// Ajusta la proyección y la vista cuando la ventana cambia de tamaño
void Visualizer::reshape(int width, int height) {
    glViewport(0, 0, width, height); // Ajusta la viewport
    glMatrixMode(GL_PROJECTION);     // Cambia a la matriz de proyección
    glLoadIdentity();                // Carga la identidad

    // Configura la proyección en perspectiva
    gluPerspective(45.0, (double)width / height, 0.1, 100.0);

    glMatrixMode(GL_MODELVIEW);      // Cambia a la matriz de modelo/vista
    glLoadIdentity();                // Carga la identidad

    // Configura la cámara para que mire al origen
}

// Configura la pose de la cámara
void Visualizer::setPose(const cv::Mat& rotVec, const cv::Mat& transVec) {
    rotationVector = rotVec;
    translationVector = transVec;
}

// Función de visualización
void Visualizer::display() const {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    
    // Configura la vista de la cámara
    if (!rotationVector.empty() && !translationVector.empty()) {
        GLfloat modelviewMatrix[16];
        cv::Mat rotationMatrix;
        cv::Rodrigues(rotationVector, rotationMatrix);

        // Rellenar la matriz de modelo/vista
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                modelviewMatrix[i * 4 + j] = rotationMatrix.at<double>(i, j);
            }
            modelviewMatrix[i * 4 + 3] = translationVector.at<double>(i, 0);
        }
        modelviewMatrix[3] = 0.0f;
        modelviewMatrix[7] = 0.0f;
        modelviewMatrix[11] = 0.0f;
        modelviewMatrix[15] = 1.0f;

        glMultMatrixf(modelviewMatrix);
    }

    // Dibuja los triángulos
    glBegin(GL_TRIANGLES);
    for (const auto& t : triangles) {
        glVertex3f(t.x1, t.y1, t.z1);
        glVertex3f(t.x2, t.y2, t.z2);
        glVertex3f(t.x3, t.y3, t.z3);
    }
    glEnd();

    // Verifica errores de OpenGL
    GLenum err = glGetError();
    if (err != GL_NO_ERROR) {
        std::cerr << "OpenGL error: " << err << std::endl;
    }

    glutSwapBuffers();
}

// Ejecuta el bucle principal de GLUT
void Visualizer::run() {
    glutMainLoop();
}
