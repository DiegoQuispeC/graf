#include "Triangulation3D.h"
#include <fstream>
#include <iostream>

Triangulation3D::Triangulation3D() {}

void Triangulation3D::loadPointsFromFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }

    double x, y, z, nx, ny, nz;
    while (file >> x >> y >> z >> nx >> ny >> nz) {
        points.push_back(Point_3(x, y, z));
    }

    file.close();
}

void Triangulation3D::performTriangulation() {
    triangulation.insert(points.begin(), points.end());
}

void Triangulation3D::saveTriangulationToFile(const std::string& filename) const {
    std::ofstream file(filename);
    if (!file) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }

    // Guardar triángulos
    for (auto f = triangulation.finite_facets_begin(); f != triangulation.finite_facets_end(); ++f) {
        // Aquí usamos los índices para representar los vértices
        file << f->first->vertex((f->second + 1) % 4)->point().x() << " "
             << f->first->vertex((f->second + 1) % 4)->point().y() << " "
             << f->first->vertex((f->second + 1) % 4)->point().z() << " "
             << f->first->vertex((f->second + 2) % 4)->point().x() << " "
             << f->first->vertex((f->second + 2) % 4)->point().y() << " "
             << f->first->vertex((f->second + 2) % 4)->point().z() << " "
             << f->first->vertex((f->second + 3) % 4)->point().x() << " "
             << f->first->vertex((f->second + 3) % 4)->point().y() << " "
             << f->first->vertex((f->second + 3) % 4)->point().z() << std::endl;
    }

    file.close();
}