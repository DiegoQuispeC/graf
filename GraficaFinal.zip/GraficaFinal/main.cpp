#include <opencv2/opencv.hpp>
#include "ChessboardDetector.h"
#include "Triangulation3D.h"
#include "Visualizer.h"
#include "CameraCalibration.h"
#include <iostream>

void calibracion()
{
    // Define el tamaño del tablero de ajedrez
    int boardWidth = 7;  // Número de esquinas internas en ancho
    int boardHeight = 7; // Número de esquinas internas en alto
    float squareSize = 2.5f; // Tamaño de cada cuadrado en cm

    CameraCalibration calib(boardWidth, boardHeight, squareSize);

    // Leer las imágenes del tablero de ajedrez
    std::vector<std::string> images = {
                                "/home/lycan/Documentos/GraficaFinal/img/img1.jpg", 
                                "/home/lycan/Documentos/GraficaFinal/img/img2.jpg", 
                                "/home/lycan/Documentos/GraficaFinal/img/img3.jpg", 
                                "/home/lycan/Documentos/GraficaFinal/img/img4.jpg", 
                                "/home/lycan/Documentos/GraficaFinal/img/img5.jpg", 
                                "/home/lycan/Documentos/GraficaFinal/img/img6.jpg", 
                                "/home/lycan/Documentos/GraficaFinal/img/img7.jpg", 
                                "/home/lycan/Documentos/GraficaFinal/img/img8.jpg"
    };

    for (const auto& image : images) {
        cv::Mat img = cv::imread(image);
        if (img.empty()) {
            std::cerr << "No se pudo abrir la imagen " << image << std::endl;
            continue;
        }
        calib.addImage(img);
    }

    calib.calibrate();
    calib.saveCalibration("calibration.yml");
}

void triangulacion()
{
    Triangulation3D triangulation;

    // Cargar puntos del archivo
    triangulation.loadPointsFromFile("/home/lycan/Documentos/GraficaFinal/final.asc");

    // Realizar la triangulación Delaunay
    triangulation.performTriangulation();

    // Guardar los resultados en un archivo
    triangulation.saveTriangulationToFile("result.txt");
}

int main(int argc, char** argv) {
    calibracion();
    triangulacion();
    
    // Configurar el detector de tablero de ajedrez
    ChessboardDetector detector(7, 7, 0.025); // 7x7 tablero de ajedrez con tamaño de cuadro de 25mm (0.025m)

    // Leer los parámetros de calibración
    cv::Mat cameraMatrix, distCoeffs;
    cv::FileStorage fs("calibration.yml", cv::FileStorage::READ);
    if (!fs.isOpened()) {
        std::cerr << "Error al abrir el archivo de calibración" << std::endl;
        return -1;
    }
    fs["cameraMatrix"] >> cameraMatrix;
    fs["distCoeffs"] >> distCoeffs;
    fs.release();

    detector.loadTriangulationResults("result.txt"); // Cargar los resultados de la triangulación

    // Inicializar el visualizador
    Visualizer visualizer(argc, argv);
    visualizer.loadTrianglesFromFile("result.txt");

    // Captura de video
    cv::VideoCapture cap(0);
    if (!cap.isOpened()) {
        std::cerr << "Error al abrir la cámara" << std::endl;
        return -1;
    }

    cv::Mat frame, undistortedFrame;
    std::vector<cv::Point2f> cornerPoints;
    cv::Mat rotationVector, translationVector;

    while (true) {
        cap >> frame;
        if (frame.empty()) break;

        // Corregir la distorsión de la imagen
        cv::undistort(frame, undistortedFrame, cameraMatrix, distCoeffs);

        // Detectar el tablero de ajedrez en la imagen corregida
        if (detector.detect(undistortedFrame, cornerPoints)) {
            // Dibujar las esquinas
            detector.drawCorners(undistortedFrame, cornerPoints);

            // Estimar la pose
            if (detector.estimatePose(cornerPoints, rotationVector, translationVector)) {
                // Dibujar los ejes
                detector.drawAxes(undistortedFrame, rotationVector, translationVector);
                // Dibujar los triángulos
                detector.drawTriangles(undistortedFrame, rotationVector, translationVector);
                
                // Actualizar la pose en OpenGL
                visualizer.setPose(rotationVector, translationVector);
            }
        }

        // Mostrar el frame corregido
        cv::imshow("Tablero de ajedrez", undistortedFrame);

        // Ejecutar el bucle principal de OpenGL
        visualizer.display(); // Llamada a la función de visualización en tiempo real

        if (cv::waitKey(30) >= 0) break;
    }

    // Ejecutar el bucle principal de GLUT (OpenGL)
    visualizer.run();

    return 0;
}
