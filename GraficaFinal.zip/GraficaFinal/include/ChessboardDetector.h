#ifndef CHESSBOARD_DETECTOR_H
#define CHESSBOARD_DETECTOR_H

#include <opencv2/opencv.hpp>

class ChessboardDetector {
public:
    ChessboardDetector(int cornersX, int cornersY, float squareSize);
    bool detect(const cv::Mat& frame, std::vector<cv::Point2f>& cornerPoints);
    void drawCorners(cv::Mat& frame, const std::vector<cv::Point2f>& cornerPoints);
    bool estimatePose(const std::vector<cv::Point2f>& cornerPoints, cv::Mat& rotationVector, cv::Mat& translationVector);
    void drawAxes(cv::Mat& frame, const cv::Mat& rotationVector, const cv::Mat& translationVector);
    void loadTriangulationResults(const std::string& filename); // Añadida
    void drawTriangles(cv::Mat& frame, const cv::Mat& rotationVector, const cv::Mat& translationVector); // Añadida

private:
    int cornersX;
    int cornersY;
    float squareSize;
    cv::Size patternSize;
    std::vector<cv::Point3f> objectPoints;
    cv::Mat cameraMatrix;
    cv::Mat distCoeffs;
    std::vector<cv::Point3f> triangulationPoints;
};

#endif // CHESSBOARD_DETECTOR_H
